// src/routes/MainRoutes.jsx
import { lazy } from 'react';
import { useUser } from '../contexts/UserContext';

// project imports
import Loadable from 'components/Loadable';
import DashboardLayout from 'layout/Dashboard';
import ProtectedRoute from './ProtectedRoute';
import Eto from 'pages/ETo/Eto';
import UsersManagement from 'pages/admin/UsersManagement';
import RolesManagement from 'pages/admin/RolesManagement';

// render - dashboard
const DashboardDefault = Loadable(lazy(() => import('pages/dashboard/default')));

// render - component overview
const Color = Loadable(lazy(() => import('pages/component-overview/color')));
const Typography = Loadable(lazy(() => import('pages/component-overview/typography')));
const Shadow = Loadable(lazy(() => import('pages/component-overview/shadows')));

// render - extra pages
const SamplePage = Loadable(lazy(() => import('pages/extra-pages/sample-page')));

// Componente wrapper que usa el contexto para definir rutas protegidas según rol
const AdminRoute = ({ children }) => {
  const { user } = useUser();
  if (user?.role === 'admin') return children;
  return (
    <div style={{ padding: '20px', textAlign: 'center' }}>
      <h2>No tienes permisos para acceder a esta página.</h2>
    </div>
  );
};

const MainRoutes = {
  path: '/',
  element: (
    <ProtectedRoute>
      <DashboardLayout />
    </ProtectedRoute>
  ),
  children: [
    {
      path: '/',
      element: <DashboardDefault />
    },
    {
      path: 'dashboard',
      children: [
        {
          path: 'default',
          element: <DashboardDefault />
        }
      ]
    },
    {
      path: 'admin',
      children: [
        {
          path: 'users',
          element: (
            <AdminRoute>
              <UsersManagement />
            </AdminRoute>
          )
        },
        {
          path: 'roles',
          element: (
            <AdminRoute>
              <RolesManagement />
            </AdminRoute>
          )
        }
      ]
    },
    {
      path: 'eto',
      element: <Eto />
    }
  ]
};

export default MainRoutes;
